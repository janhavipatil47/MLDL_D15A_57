Notification Preferences Export

The Notification Preferences data file contains the email notification settings for the user.

Files included:
----------

Notification Preferences.csv

The data for User MBD:

    emailWeeklyStats                 - Weekly totals, daily averages, bests and comparisons with friends.
    emailMarketing                   - Emails with news and updates about Fitbit products and services.
    emailResearch                    - Emails with opportunities to participate in research studies.
